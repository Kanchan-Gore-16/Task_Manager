import { classifyTask } from "./utils/classifier.js";

console.log(classifyTask("Urgent meeting today"));
